# Status — where this was left off

Every module below compiles clean under `cargo check` and `cargo test`
(verified in-sandbox against rustc 1.75). `main.rs` is still just a stub
that declares the modules and prints "ok" — nothing is wired together yet.
That's the one real gap: everything is built, nothing is assembled.

## What's done and verified

- `errors.rs` — `AgentError` enum, `thiserror`-based.
- `config.rs` — env-var driven `Config` struct, matches the env var names
  used in the earlier Go version's `.env` files (`R2_ENDPOINT`, `R2_BUCKET`,
  `SYNC_INTERVAL`, etc.) plus new ones for this rewrite (`DOMAINS_FILE`,
  `CERT_ISSUER_SCRIPT`, `ACME_CHALLENGE_TARGET`, `DNS_RECHECK_INTERVAL`,
  `LISTEN_ADDR`, `STATE_DIR`, `KEEP_STAGE`).
- `dns.rs` — `verify_acme_challenge(domain, expected_target)` shells out to
  `dig +short CNAME`. This is the extension point for swapping in
  `artisan_middleware`'s resolver later — same function signature, swap the
  implementation.
- `domain_store.rs` — `DomainRecord` / `DomainState` (`AwaitingCname` →
  `CnameVerified` → `CertIssued` → `Published`, plus `Failed`), JSON-file
  backed via `DomainStore`, atomic write (tmp file + rename).
- `fsmirror.rs` — `copy_dir` / `mirror_dir`, ported from the Go version
  including the symlinked-directory fix. Has a passing regression test
  (`copy_dir_follows_symlinked_subdirectory`) reproducing the exact bug
  found earlier, plus a stale-file-deletion test.
- `r2.rs` — hand-rolled SigV4 client (no AWS SDK dependency). Has passing
  unit tests for URI encoding and signature determinism/key-sensitivity.
  **Not tested against a live R2 bucket** — the HTTP round-trip itself is
  unverified. Test that before trusting it in production.
- `acme.rs` — `domains.txt` writer (atomic, sorted, deduped) and
  `run_cert_issuer` (shells to the existing `/usr/local/bin/certs` script).
- `jobs.rs` — in-memory `JobStore` (start/succeed/fail/get), not yet wired
  into the scheduler or API — `scheduler.rs` and `api.rs` don't currently
  create jobs for issuance/publish runs, they just await them directly.
  Wiring real job records through those call sites is the natural next step
  if you want `/jobs/{id}` to reflect actual in-flight work.
- `sync_task.rs` — ported from the Go `nginxsync` package.
- `publish_task.rs` — ported from the Go `certpublish` package, minus the
  inline cert-issuance call (that's now the scheduler's job, decoupled from
  publish itself).
- `scheduler.rs` — `dns_recheck_pass` walks domains in `AwaitingCname`,
  calls `dns::verify_acme_challenge`, and on success calls
  `issue_and_publish` (writes `domains.txt`, runs the issuer, then calls
  `publish_task::run_once`). `run_server_loops` spawns the DNS-recheck timer
  and periodic reconciliation-publish timer. `run_sync_loop` is the edge
  daemon's loop.
- `api.rs` — axum router: `GET /health`, `GET/POST /domains`,
  `GET/DELETE /domains/{domain}`, `POST /domains/{domain}/recheck`,
  `GET /jobs/{id}`. `POST /domains` runs the CNAME preflight synchronously
  and returns 422 with the exact record to add if it fails; on success it
  spawns `issue_and_publish` in the background rather than blocking the
  request on a multi-minute ACME run.

## What's not done

1. **`main.rs` doesn't call any of this.** Needs: arg parsing for
   `server` / `sync` subcommands, `Config::from_env()`, building the
   `R2Client`, `DomainStore::load`, `JobStore::default()`, then either
   `scheduler::run_server_loops` + `axum::serve(...)` for `server` mode, or
   `scheduler::run_sync_loop` for `sync` mode. Everything it needs already
   exists as a function — this is pure wiring, no new logic.
2. **No live test of `r2.rs` against an actual R2 bucket.** The signing
   logic has unit tests; the HTTP behavior does not.
3. **No Makefile or systemd units yet** for this project (the Go version's
   `deploy/` directory is a reasonable template to copy from and adapt —
   swap `ExecStart` for this binary's `server`/`sync` subcommands and add
   the new env vars).
4. **`jobs.rs` isn't connected to anything real yet** — see above.

## Dependency pinning — why Cargo.toml looks the way it does

The sandbox's Rust toolchain (`apt`-installed, 1.75.0, Dec 2023) is old
enough that a lot of the current crates.io ecosystem has since bumped to
`edition2024`, which that toolchain can't parse at all — not a compile
error, a hard "can't even read this Cargo.toml" error. Getting a clean
build meant pinning several transitive dependencies to their last
pre-edition2024 versions: `url`, `idna`, `encoding_rs`, `hashbrown`,
`indexmap`, `getrandom`, and `uuid`. `Cargo.lock` is included and known to
resolve and build correctly under 1.75.

If you build this on a machine with a current Rust toolchain (1.80+,
whatever's current when you pick this back up), these pins are probably
unnecessary — feel free to delete them from `Cargo.toml`, delete
`Cargo.lock`, and run `cargo update` to let everything resolve to current
versions normally. The pins exist entirely because of the sandbox's stale
toolchain, not because of anything in this codebase.

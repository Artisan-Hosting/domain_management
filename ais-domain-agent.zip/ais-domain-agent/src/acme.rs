use std::path::Path;

use tokio::process::Command;

use crate::errors::{AgentError, Result};

pub async fn write_domains_file(path: &Path, domains: &[String]) -> Result<()> {
    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    let mut sorted = domains.to_vec();
    sorted.sort();
    sorted.dedup();
    let contents = sorted.join("\n") + "\n";

    let tmp_path = path.with_extension("txt.tmp");
    tokio::fs::write(&tmp_path, contents).await?;
    tokio::fs::rename(&tmp_path, path).await?;
    Ok(())
}

pub async fn run_cert_issuer(script_path: &Path) -> Result<String> {
    let output = Command::new("bash")
        .arg(script_path)
        .output()
        .await
        .map_err(|e| AgentError::Acme(format!("running {}: {e}", script_path.display())))?;

    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    let combined = format!("{stdout}\n{stderr}");

    if !output.status.success() {
        return Err(AgentError::Acme(format!(
            "cert issuer exited with {}: {combined}",
            output.status
        )));
    }

    Ok(combined)
}

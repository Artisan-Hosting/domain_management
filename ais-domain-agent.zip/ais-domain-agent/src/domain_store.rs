use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;

use crate::errors::Result;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DomainKind {
    Apex,
    Sub,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "state")]
pub enum DomainState {
    AwaitingCname,
    CnameVerified,
    CertIssued,
    Published,
    Failed { reason: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DomainRecord {
    pub domain: String,
    pub kind: DomainKind,
    pub state: DomainState,
    pub added_at: DateTime<Utc>,
    pub cname_checked_at: Option<DateTime<Utc>>,
    pub cname_verified_at: Option<DateTime<Utc>>,
    pub cert_issued_at: Option<DateTime<Utc>>,
    pub published_at: Option<DateTime<Utc>>,
    pub last_error: Option<String>,
}

impl DomainRecord {
    pub fn new(domain: String, kind: DomainKind) -> Self {
        DomainRecord {
            domain,
            kind,
            state: DomainState::AwaitingCname,
            added_at: Utc::now(),
            cname_checked_at: None,
            cname_verified_at: None,
            cert_issued_at: None,
            published_at: None,
            last_error: None,
        }
    }
}

#[derive(Clone)]
pub struct DomainStore {
    path: PathBuf,
    inner: Arc<RwLock<HashMap<String, DomainRecord>>>,
}

impl DomainStore {
    pub async fn load(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref().to_path_buf();
        let map = match tokio::fs::read(&path).await {
            Ok(bytes) => serde_json::from_slice(&bytes)?,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => HashMap::new(),
            Err(e) => return Err(e.into()),
        };
        Ok(DomainStore {
            path,
            inner: Arc::new(RwLock::new(map)),
        })
    }

    async fn persist(&self, map: &HashMap<String, DomainRecord>) -> Result<()> {
        if let Some(parent) = self.path.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }
        let tmp_path = self.path.with_extension("json.tmp");
        let bytes = serde_json::to_vec_pretty(map)?;
        tokio::fs::write(&tmp_path, bytes).await?;
        tokio::fs::rename(&tmp_path, &self.path).await?;
        Ok(())
    }

    pub async fn upsert(&self, record: DomainRecord) -> Result<()> {
        let mut map = self.inner.write().await;
        map.insert(record.domain.clone(), record);
        self.persist(&map).await
    }

    pub async fn get(&self, domain: &str) -> Option<DomainRecord> {
        self.inner.read().await.get(domain).cloned()
    }

    pub async fn list(&self) -> Vec<DomainRecord> {
        self.inner.read().await.values().cloned().collect()
    }

    pub async fn remove(&self, domain: &str) -> Result<Option<DomainRecord>> {
        let mut map = self.inner.write().await;
        let removed = map.remove(domain);
        self.persist(&map).await?;
        Ok(removed)
    }

    pub async fn domains_in_state(&self, matches: impl Fn(&DomainState) -> bool) -> Vec<String> {
        self.inner
            .read()
            .await
            .values()
            .filter(|r| matches(&r.state))
            .map(|r| r.domain.clone())
            .collect()
    }

    pub async fn cert_issued_domains(&self) -> Vec<String> {
        self.inner
            .read()
            .await
            .values()
            .filter(|r| r.state == DomainState::CertIssued)
            .map(|r| r.domain.clone())
            .collect()
    }
}

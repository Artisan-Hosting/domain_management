use std::collections::HashMap;
use std::path::Path;

use chrono::Utc;
use hmac::{Hmac, Mac};
use md5::Md5;
use sha2::{Digest, Sha256};

use crate::errors::{AgentError, Result};

type HmacSha256 = Hmac<Sha256>;

#[derive(Debug, Clone)]
pub struct RemoteObject {
    pub etag: String,
    pub size: u64,
}

#[derive(Clone)]
pub struct R2Client {
    host: String,
    bucket: String,
    access_key: String,
    secret_key: String,
    http: reqwest::Client,
}

fn aws_uri_encode(s: &str, encode_slash: bool) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        let c = b as char;
        if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' || c == '~' {
            out.push(c);
        } else if c == '/' && !encode_slash {
            out.push(c);
        } else {
            out.push_str(&format!("%{:02X}", b));
        }
    }
    out
}

fn sha256_hex(data: &[u8]) -> String {
    hex::encode(Sha256::digest(data))
}

fn md5_hex(data: &[u8]) -> String {
    hex::encode(Md5::digest(data))
}

fn hmac_bytes(key: &[u8], data: &[u8]) -> Vec<u8> {
    let mut mac = HmacSha256::new_from_slice(key).expect("hmac accepts any key length");
    mac.update(data);
    mac.finalize().into_bytes().to_vec()
}

impl R2Client {
    pub fn new(endpoint: &str, bucket: &str, access_key: &str, secret_key: &str) -> Result<Self> {
        let host = endpoint
            .trim_start_matches("https://")
            .trim_start_matches("http://")
            .trim_end_matches('/')
            .to_string();
        Ok(R2Client {
            host,
            bucket: bucket.to_string(),
            access_key: access_key.to_string(),
            secret_key: secret_key.to_string(),
            http: reqwest::Client::new(),
        })
    }

    fn sign(
        &self,
        method: &str,
        canonical_uri: &str,
        canonical_query: &str,
        payload_hash: &str,
    ) -> (String, String) {
        let now = Utc::now();
        let amz_date = now.format("%Y%m%dT%H%M%SZ").to_string();
        let date_stamp = now.format("%Y%m%d").to_string();

        let canonical_headers = format!(
            "host:{}\nx-amz-content-sha256:{}\nx-amz-date:{}\n",
            self.host, payload_hash, amz_date
        );
        let signed_headers = "host;x-amz-content-sha256;x-amz-date";

        let canonical_request = format!(
            "{}\n{}\n{}\n{}\n{}\n{}",
            method, canonical_uri, canonical_query, canonical_headers, signed_headers, payload_hash
        );
        let hashed_canonical_request = sha256_hex(canonical_request.as_bytes());

        let credential_scope = format!("{}/auto/s3/aws4_request", date_stamp);
        let string_to_sign = format!(
            "AWS4-HMAC-SHA256\n{}\n{}\n{}",
            amz_date, credential_scope, hashed_canonical_request
        );

        let k_date = hmac_bytes(format!("AWS4{}", self.secret_key).as_bytes(), date_stamp.as_bytes());
        let k_region = hmac_bytes(&k_date, b"auto");
        let k_service = hmac_bytes(&k_region, b"s3");
        let k_signing = hmac_bytes(&k_service, b"aws4_request");
        let signature = hex::encode(hmac_bytes(&k_signing, string_to_sign.as_bytes()));

        let authorization = format!(
            "AWS4-HMAC-SHA256 Credential={}/{}, SignedHeaders={}, Signature={}",
            self.access_key, credential_scope, signed_headers, signature
        );

        (authorization, amz_date)
    }

    async fn request(
        &self,
        method: reqwest::Method,
        key: &str,
        query: &[(&str, &str)],
        body: Option<Vec<u8>>,
    ) -> Result<reqwest::Response> {
        let canonical_uri = format!(
            "/{}/{}",
            aws_uri_encode(&self.bucket, false),
            aws_uri_encode(key, false)
        );

        let mut sorted_query = query.to_vec();
        sorted_query.sort_by(|a, b| a.0.cmp(b.0));
        let canonical_query = sorted_query
            .iter()
            .map(|(k, v)| format!("{}={}", aws_uri_encode(k, true), aws_uri_encode(v, true)))
            .collect::<Vec<_>>()
            .join("&");

        let payload_hash = sha256_hex(body.as_deref().unwrap_or(&[]));
        let (authorization, amz_date) =
            self.sign(method.as_str(), &canonical_uri, &canonical_query, &payload_hash);

        let mut url = format!("https://{}{}", self.host, canonical_uri);
        if !canonical_query.is_empty() {
            url.push('?');
            url.push_str(&canonical_query);
        }

        let mut req = self
            .http
            .request(method, &url)
            .header("x-amz-date", amz_date)
            .header("x-amz-content-sha256", &payload_hash)
            .header("Authorization", authorization);

        if let Some(b) = body {
            req = req.body(b);
        }

        let resp = req
            .send()
            .await
            .map_err(|e| AgentError::R2(format!("request to {url} failed: {e}")))?;

        if !resp.status().is_success() && resp.status().as_u16() != 404 {
            let status = resp.status();
            let text = resp.text().await.unwrap_or_default();
            return Err(AgentError::R2(format!(
                "request to {url} returned {status}: {text}"
            )));
        }

        Ok(resp)
    }

    pub async fn get_object_bytes(&self, key: &str) -> Result<Option<Vec<u8>>> {
        let resp = self.request(reqwest::Method::GET, key, &[], None).await?;
        if resp.status().as_u16() == 404 {
            return Ok(None);
        }
        Ok(Some(resp.bytes().await?.to_vec()))
    }

    pub async fn get_object_string(&self, key: &str) -> Result<String> {
        let bytes = self
            .get_object_bytes(key)
            .await?
            .ok_or_else(|| AgentError::NotFound(key.to_string()))?;
        Ok(String::from_utf8_lossy(&bytes).trim().to_string())
    }

    pub async fn put_object_bytes(&self, key: &str, body: Vec<u8>) -> Result<()> {
        self.request(reqwest::Method::PUT, key, &[], Some(body))
            .await?;
        Ok(())
    }

    pub async fn put_object_string(&self, key: &str, value: &str) -> Result<()> {
        self.put_object_bytes(key, value.as_bytes().to_vec()).await
    }

    pub async fn put_file(&self, key: &str, path: &Path) -> Result<()> {
        let bytes = tokio::fs::read(path).await?;
        self.put_object_bytes(key, bytes).await
    }

    pub async fn delete_object(&self, key: &str) -> Result<()> {
        self.request(reqwest::Method::DELETE, key, &[], None).await?;
        Ok(())
    }

    async fn list_tree(&self, prefix: &str) -> Result<HashMap<String, RemoteObject>> {
        let mut objects = HashMap::new();
        let mut continuation_token: Option<String> = None;
        let full_prefix = format!("{}/", prefix);

        loop {
            let mut query = vec![("list-type", "2"), ("prefix", full_prefix.as_str())];
            if let Some(token) = &continuation_token {
                query.push(("continuation-token", token.as_str()));
            }

            let resp = self.request(reqwest::Method::GET, "", &query, None).await?;
            let body = resp.text().await?;
            let doc = roxmltree::Document::parse(&body)
                .map_err(|e| AgentError::R2(format!("parsing list-objects response: {e}")))?;

            for node in doc.descendants().filter(|n| n.has_tag_name("Contents")) {
                let key = node
                    .children()
                    .find(|c| c.has_tag_name("Key"))
                    .and_then(|c| c.text())
                    .unwrap_or_default()
                    .to_string();
                let etag = node
                    .children()
                    .find(|c| c.has_tag_name("ETag"))
                    .and_then(|c| c.text())
                    .unwrap_or_default()
                    .trim_matches('"')
                    .to_string();
                let size: u64 = node
                    .children()
                    .find(|c| c.has_tag_name("Size"))
                    .and_then(|c| c.text())
                    .and_then(|t| t.parse().ok())
                    .unwrap_or(0);

                if let Some(rel) = key.strip_prefix(&full_prefix) {
                    if !rel.is_empty() {
                        objects.insert(rel.to_string(), RemoteObject { etag, size });
                    }
                }
            }

            let is_truncated = doc
                .descendants()
                .find(|n| n.has_tag_name("IsTruncated"))
                .and_then(|n| n.text())
                .map(|t| t == "true")
                .unwrap_or(false);

            if !is_truncated {
                break;
            }
            continuation_token = doc
                .descendants()
                .find(|n| n.has_tag_name("NextContinuationToken"))
                .and_then(|n| n.text())
                .map(|s| s.to_string());
            if continuation_token.is_none() {
                break;
            }
        }

        Ok(objects)
    }

    pub async fn download_tree(&self, remote_prefix: &str, local_dir: &Path) -> Result<()> {
        let remote = self.list_tree(remote_prefix).await?;
        tokio::fs::create_dir_all(local_dir).await?;

        for (rel, obj) in &remote {
            let local_path = local_dir.join(rel);
            let needs_download = match tokio::fs::metadata(&local_path).await {
                Ok(meta) if meta.len() == obj.size => local_md5(&local_path).await? != obj.etag,
                _ => true,
            };
            if !needs_download {
                continue;
            }
            if let Some(parent) = local_path.parent() {
                tokio::fs::create_dir_all(parent).await?;
            }
            let key = format!("{}/{}", remote_prefix, rel);
            if let Some(bytes) = self.get_object_bytes(&key).await? {
                tokio::fs::write(&local_path, bytes).await?;
            }
        }

        remove_local_files_not_in(local_dir, &remote).await?;
        Ok(())
    }

    pub async fn upload_tree(&self, local_dir: &Path, remote_prefix: &str) -> Result<()> {
        let remote = self.list_tree(remote_prefix).await?;
        let mut seen = std::collections::HashSet::new();

        for entry in walkdir::WalkDir::new(local_dir).follow_links(false) {
            let entry = entry.map_err(std::io::Error::from)?;
            if entry.file_type().is_dir() {
                continue;
            }
            let rel = entry
                .path()
                .strip_prefix(local_dir)
                .unwrap()
                .to_string_lossy()
                .replace('\\', "/");
            seen.insert(rel.clone());

            let bytes = tokio::fs::read(entry.path()).await?;
            let sum = md5_hex(&bytes);
            let size = bytes.len() as u64;

            if let Some(obj) = remote.get(&rel) {
                if obj.size == size && obj.etag == sum {
                    continue;
                }
            }
            let key = format!("{}/{}", remote_prefix, rel);
            self.put_object_bytes(&key, bytes).await?;
        }

        for rel in remote.keys() {
            if !seen.contains(rel) {
                let key = format!("{}/{}", remote_prefix, rel);
                self.delete_object(&key).await?;
            }
        }

        Ok(())
    }
}

async fn local_md5(path: &Path) -> Result<String> {
    let bytes = tokio::fs::read(path).await?;
    Ok(md5_hex(&bytes))
}

async fn remove_local_files_not_in(
    local_dir: &Path,
    remote: &HashMap<String, RemoteObject>,
) -> Result<()> {
    let mut to_remove = Vec::new();
    for entry in walkdir::WalkDir::new(local_dir).follow_links(false) {
        let entry = entry.map_err(std::io::Error::from)?;
        if entry.file_type().is_dir() {
            continue;
        }
        let rel = entry
            .path()
            .strip_prefix(local_dir)
            .unwrap()
            .to_string_lossy()
            .replace('\\', "/");
        if !remote.contains_key(&rel) {
            to_remove.push(entry.path().to_path_buf());
        }
    }
    for path in to_remove {
        tokio::fs::remove_file(path).await?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn uri_encode_leaves_unreserved_untouched() {
        assert_eq!(aws_uri_encode("abc-DEF_123.~", false), "abc-DEF_123.~");
    }

    #[test]
    fn uri_encode_preserves_slash_unless_asked() {
        assert_eq!(aws_uri_encode("a/b c", false), "a/b%20c");
        assert_eq!(aws_uri_encode("a/b c", true), "a%2Fb%20c");
    }

    #[test]
    fn signature_is_deterministic_and_key_sensitive() {
        let client_a = R2Client::new("https://example.r2.cloudflarestorage.com", "bucket", "AKID", "secret").unwrap();
        let client_b = R2Client::new("https://example.r2.cloudflarestorage.com", "bucket", "AKID", "other-secret").unwrap();

        let (sig_a1, _) = client_a.sign("GET", "/bucket/key", "", &sha256_hex(b""));
        let (sig_a2, _) = client_a.sign("GET", "/bucket/key", "", &sha256_hex(b""));
        let (sig_b, _) = client_b.sign("GET", "/bucket/key", "", &sha256_hex(b""));

        assert_ne!(sig_a1, sig_b);
        assert!(sig_a1.contains("Credential=AKID/"));
        assert!(sig_a2.contains("Credential=AKID/"));
    }
}

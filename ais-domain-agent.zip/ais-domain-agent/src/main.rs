mod acme;
mod api;
mod config;
mod dns;
mod domain_store;
mod errors;
mod fsmirror;
mod jobs;
mod publish_task;
mod r2;
mod scheduler;
mod sync_task;

fn main() {
    println!("ok");
}

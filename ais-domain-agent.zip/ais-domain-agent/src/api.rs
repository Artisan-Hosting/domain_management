use std::sync::Arc;

use axum::extract::{Path as AxPath, State};
use axum::http::StatusCode;
use axum::routing::{delete, get, post};
use axum::{Json, Router};
use serde::{Deserialize, Serialize};

use crate::config::Config;
use crate::dns;
use crate::domain_store::{DomainKind, DomainRecord, DomainState, DomainStore};
use crate::jobs::{Job, JobStore};
use crate::r2::R2Client;
use crate::scheduler;

#[derive(Clone)]
pub struct AppState {
    pub cfg: Arc<Config>,
    pub store: DomainStore,
    pub jobs: JobStore,
    pub r2: R2Client,
}

pub fn router(state: AppState) -> Router {
    Router::new()
        .route("/health", get(health))
        .route("/domains", get(list_domains).post(add_domain))
        .route("/domains/:domain", get(get_domain).delete(remove_domain))
        .route("/domains/:domain/recheck", post(recheck_domain))
        .route("/jobs/:id", get(get_job))
        .with_state(state)
}

async fn health() -> &'static str {
    "ok"
}

#[derive(Deserialize)]
struct AddDomainRequest {
    domain: String,
    #[serde(default)]
    kind: Option<String>,
}

#[derive(Serialize)]
struct ErrorBody {
    error: String,
}

fn err(status: StatusCode, msg: impl Into<String>) -> (StatusCode, Json<ErrorBody>) {
    (status, Json(ErrorBody { error: msg.into() }))
}

async fn list_domains(State(state): State<AppState>) -> Json<Vec<DomainRecord>> {
    Json(state.store.list().await)
}

async fn get_domain(
    State(state): State<AppState>,
    AxPath(domain): AxPath<String>,
) -> Result<Json<DomainRecord>, (StatusCode, Json<ErrorBody>)> {
    state
        .store
        .get(&domain)
        .await
        .map(Json)
        .ok_or_else(|| err(StatusCode::NOT_FOUND, format!("unknown domain {domain}")))
}

async fn add_domain(
    State(state): State<AppState>,
    Json(req): Json<AddDomainRequest>,
) -> Result<Json<DomainRecord>, (StatusCode, Json<ErrorBody>)> {
    let kind = match req.kind.as_deref() {
        Some("apex") => DomainKind::Apex,
        _ => DomainKind::Sub,
    };

    let verified = dns::verify_acme_challenge(&req.domain, &state.cfg.acme_challenge_target)
        .await
        .unwrap_or(false);

    let mut record = DomainRecord::new(req.domain.clone(), kind);
    record.cname_checked_at = Some(chrono::Utc::now());

    if !verified {
        state
            .store
            .upsert(record.clone())
            .await
            .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
        return Err(err(
            StatusCode::UNPROCESSABLE_ENTITY,
            format!(
                "CNAME not found or mismatched. Add: _acme-challenge.{} CNAME {}",
                req.domain, state.cfg.acme_challenge_target
            ),
        ));
    }

    record.state = DomainState::CnameVerified;
    record.cname_verified_at = Some(chrono::Utc::now());
    state
        .store
        .upsert(record.clone())
        .await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    let cfg = state.cfg.clone();
    let store = state.store.clone();
    let r2 = state.r2.clone();
    let domain = req.domain.clone();
    tokio::spawn(async move {
        scheduler::issue_and_publish(&cfg, &store, &r2, &domain).await;
    });

    Ok(Json(record))
}

async fn remove_domain(
    State(state): State<AppState>,
    AxPath(domain): AxPath<String>,
) -> Result<Json<DomainRecord>, (StatusCode, Json<ErrorBody>)> {
    state
        .store
        .remove(&domain)
        .await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
        .map(Json)
        .ok_or_else(|| err(StatusCode::NOT_FOUND, format!("unknown domain {domain}")))
}

async fn recheck_domain(
    State(state): State<AppState>,
    AxPath(domain): AxPath<String>,
) -> Result<Json<DomainRecord>, (StatusCode, Json<ErrorBody>)> {
    let mut record = state
        .store
        .get(&domain)
        .await
        .ok_or_else(|| err(StatusCode::NOT_FOUND, format!("unknown domain {domain}")))?;

    let verified = dns::verify_acme_challenge(&domain, &state.cfg.acme_challenge_target)
        .await
        .unwrap_or(false);
    record.cname_checked_at = Some(chrono::Utc::now());

    if verified && record.state == DomainState::AwaitingCname {
        record.state = DomainState::CnameVerified;
        record.cname_verified_at = Some(chrono::Utc::now());
    }

    state
        .store
        .upsert(record.clone())
        .await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    if verified {
        let cfg = state.cfg.clone();
        let store = state.store.clone();
        let r2 = state.r2.clone();
        tokio::spawn(async move {
            scheduler::issue_and_publish(&cfg, &store, &r2, &domain).await;
        });
    }

    Ok(Json(record))
}

async fn get_job(
    State(state): State<AppState>,
    AxPath(id): AxPath<uuid::Uuid>,
) -> Result<Json<Job>, (StatusCode, Json<ErrorBody>)> {
    state
        .jobs
        .get(id)
        .await
        .map(Json)
        .ok_or_else(|| err(StatusCode::NOT_FOUND, format!("unknown job {id}")))
}

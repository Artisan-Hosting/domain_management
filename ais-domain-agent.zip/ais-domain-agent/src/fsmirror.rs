use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

use walkdir::WalkDir;

use crate::errors::{AgentError, Result};

pub async fn copy_dir_async(src: PathBuf, dst: PathBuf) -> Result<()> {
    tokio::task::spawn_blocking(move || copy_dir(&src, &dst))
        .await
        .map_err(|e| AgentError::Io(std::io::Error::other(e.to_string())))?
}

pub async fn mirror_dir_async(src: PathBuf, dst: PathBuf) -> Result<()> {
    tokio::task::spawn_blocking(move || mirror_dir(&src, &dst))
        .await
        .map_err(|e| AgentError::Io(std::io::Error::other(e.to_string())))?
}

pub fn copy_dir(src: &Path, dst: &Path) -> Result<()> {
    for entry in WalkDir::new(src).min_depth(0).follow_links(false) {
        let entry = entry.map_err(std::io::Error::from)?;
        let rel = entry.path().strip_prefix(src).unwrap();
        let target = dst.join(rel);

        let file_type = entry.file_type();

        if file_type.is_symlink() {
            let resolved = fs::canonicalize(entry.path())?;
            let meta = fs::metadata(&resolved)?;
            if meta.is_dir() {
                copy_dir(&resolved, &target)?;
            } else {
                copy_file(&resolved, &target)?;
            }
            continue;
        }

        if file_type.is_dir() {
            let meta = entry.metadata().map_err(std::io::Error::from)?;
            fs::create_dir_all(&target)?;
            let mut perms = meta.permissions();
            perms.set_mode(perms.mode() | 0o700);
            fs::set_permissions(&target, perms)?;
            continue;
        }

        copy_file(entry.path(), &target)?;
    }
    Ok(())
}

pub fn mirror_dir(src: &Path, dst: &Path) -> Result<()> {
    fs::create_dir_all(dst)?;
    copy_dir(src, dst)?;

    for entry in WalkDir::new(dst).follow_links(false) {
        let entry = entry.map_err(std::io::Error::from)?;
        if entry.file_type().is_dir() {
            continue;
        }
        let rel = entry.path().strip_prefix(dst).unwrap();
        let src_counterpart = src.join(rel);
        if fs::symlink_metadata(&src_counterpart).is_err() {
            fs::remove_file(entry.path())?;
        }
    }
    Ok(())
}

fn copy_file(src: &Path, dst: &Path) -> Result<()> {
    if let Some(parent) = dst.parent() {
        fs::create_dir_all(parent)?;
    }
    fs::copy(src, dst)?;
    let meta = fs::metadata(src)?;
    fs::set_permissions(dst, meta.permissions())?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::symlink;

    #[test]
    fn copy_dir_follows_symlinked_subdirectory() {
        let tmp = std::env::temp_dir().join(format!("fsmirror-test-{}", std::process::id()));
        let real_target = tmp.join("real_target/etc/nginx");
        let src = tmp.join("src");
        let dst = tmp.join("dst");
        let _ = fs::remove_dir_all(&tmp);

        fs::create_dir_all(&real_target).unwrap();
        fs::write(real_target.join("nginx.conf"), "server { listen 80; }").unwrap();
        fs::create_dir_all(src.join("sites-enabled")).unwrap();
        fs::write(src.join("sites-enabled/default"), "site config").unwrap();
        symlink(&real_target, src.join("nginx")).unwrap();

        mirror_dir(&src, &dst).unwrap();

        let copied = fs::read_to_string(dst.join("nginx/nginx.conf")).unwrap();
        assert_eq!(copied, "server { listen 80; }");
        let sibling = fs::read_to_string(dst.join("sites-enabled/default")).unwrap();
        assert_eq!(sibling, "site config");

        fs::remove_dir_all(&tmp).ok();
    }

    #[test]
    fn mirror_dir_deletes_stale_files() {
        let tmp = std::env::temp_dir().join(format!("fsmirror-test2-{}", std::process::id()));
        let src = tmp.join("src");
        let dst = tmp.join("dst");
        let _ = fs::remove_dir_all(&tmp);

        fs::create_dir_all(&src).unwrap();
        fs::write(src.join("keep.conf"), "keep").unwrap();
        fs::create_dir_all(&dst).unwrap();
        fs::write(dst.join("stale.conf"), "stale").unwrap();

        mirror_dir(&src, &dst).unwrap();

        assert!(dst.join("keep.conf").exists());
        assert!(!dst.join("stale.conf").exists());

        fs::remove_dir_all(&tmp).ok();
    }
}

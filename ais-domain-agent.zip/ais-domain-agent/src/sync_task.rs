use std::path::PathBuf;

use tokio::process::Command;
use tracing::{error, info, warn};

use crate::config::Config;
use crate::errors::{AgentError, Result};
use crate::fsmirror::{copy_dir_async, mirror_dir_async};
use crate::r2::R2Client;

pub async fn run_once(cfg: &Config, r2: &R2Client) -> Result<()> {
    let stage_root = cfg.sync_root.join("stage");
    let backup_root = cfg.sync_root.join("backup");
    let state_dir = cfg.sync_root.join("state");
    tokio::fs::create_dir_all(&stage_root).await?;
    tokio::fs::create_dir_all(&backup_root).await?;
    tokio::fs::create_dir_all(&state_dir).await?;
    let latest_file = state_dir.join("latest_applied");

    let release_id = r2
        .get_object_string(&format!("{}/latest", cfg.r2_prefix))
        .await?;
    if release_id.is_empty() {
        return Err(AgentError::R2(format!(
            "empty release id from {}/latest",
            cfg.r2_prefix
        )));
    }

    if let Ok(applied) = tokio::fs::read_to_string(&latest_file).await {
        if applied.trim() == release_id {
            info!(release = %release_id, "already on latest release, nothing to do");
            return Ok(());
        }
    }

    let stage_dir = stage_root.join(&release_id);
    let tree_dir = stage_dir.join("tree");
    let backup_dir = backup_root.join(chrono::Utc::now().format("%Y-%m-%dT%H-%M-%SZ").to_string());

    info!(release = %release_id, "downloading release tree from R2");
    r2.download_tree(
        &format!("{}/releases/{}/tree", cfg.r2_prefix, release_id),
        &tree_dir,
    )
    .await?;

    info!(from = %cfg.etc_nginx.display(), to = %backup_dir.display(), "backing up nginx config");
    copy_dir_async(cfg.etc_nginx.clone(), backup_dir.clone()).await?;

    if cfg.sync_mode == "full" {
        info!("applying FULL tree to {}", cfg.etc_nginx.display());
        mirror_dir_async(tree_dir.clone(), cfg.etc_nginx.clone()).await?;
    } else {
        info!("applying PARTIAL paths to {}", cfg.etc_nginx.display());
        for p in &cfg.partial_paths {
            let src = tree_dir.join(p);
            if !src.exists() {
                warn!(path = %p, "not present in release tree, skipping");
                continue;
            }
            mirror_dir_async(src, cfg.etc_nginx.join(p)).await?;
        }
    }

    if let Err(e) = test_nginx().await {
        error!(error = %e, "nginx -t failed, rolling back");
        mirror_dir_async(backup_dir.clone(), cfg.etc_nginx.clone()).await?;
        if test_nginx().await.is_ok() {
            let _ = reload_nginx().await;
        }
        return Err(e);
    }

    reload_nginx().await?;
    tokio::fs::write(&latest_file, &release_id).await?;
    info!(release = %release_id, "applied release");

    prune_stage_dirs(&stage_root, &release_id).await;
    prune_backups(&backup_root, cfg.keep_backups).await;
    Ok(())
}

async fn test_nginx() -> Result<()> {
    let status = Command::new("/usr/sbin/nginx").arg("-t").status().await?;
    if status.success() {
        Ok(())
    } else {
        Err(AgentError::Config(format!("nginx -t exited with {status}")))
    }
}

async fn reload_nginx() -> Result<()> {
    let status = Command::new("systemctl")
        .args(["reload", "nginx"])
        .status()
        .await?;
    if status.success() {
        Ok(())
    } else {
        Err(AgentError::Config(format!(
            "systemctl reload nginx exited with {status}"
        )))
    }
}

async fn prune_stage_dirs(stage_root: &PathBuf, keep: &str) {
    let Ok(mut entries) = tokio::fs::read_dir(stage_root).await else {
        return;
    };
    while let Ok(Some(entry)) = entries.next_entry().await {
        if entry.file_name() != std::ffi::OsStr::new(keep) {
            let _ = tokio::fs::remove_dir_all(entry.path()).await;
        }
    }
}

async fn prune_backups(backup_root: &PathBuf, keep: usize) {
    if keep == 0 {
        return;
    }
    let Ok(mut entries) = tokio::fs::read_dir(backup_root).await else {
        return;
    };
    let mut names = Vec::new();
    while let Ok(Some(entry)) = entries.next_entry().await {
        names.push(entry.file_name());
    }
    names.sort();
    names.reverse();
    for name in names.into_iter().skip(keep) {
        let _ = tokio::fs::remove_dir_all(backup_root.join(name)).await;
    }
}

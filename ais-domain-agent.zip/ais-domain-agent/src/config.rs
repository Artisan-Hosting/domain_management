use std::path::PathBuf;
use std::time::Duration;

use crate::errors::{AgentError, Result};

#[derive(Debug, Clone)]
pub struct Config {
    pub r2_endpoint: String,
    pub r2_bucket: String,
    pub r2_prefix: String,
    pub r2_access_key_id: String,
    pub r2_secret_access_key: String,

    pub domains_file: PathBuf,
    pub cert_issuer_script: PathBuf,
    pub acme_challenge_target: String,

    pub source_tree: PathBuf,
    pub etc_nginx: PathBuf,
    pub sync_root: PathBuf,
    pub work_root: PathBuf,
    pub state_dir: PathBuf,

    pub sync_mode: String,
    pub partial_paths: Vec<String>,
    pub keep_backups: usize,
    pub keep_stage: bool,

    pub listen_addr: String,

    pub dns_recheck_interval: Duration,
    pub sync_interval: Duration,
    pub publish_interval: Duration,
}

fn env_or(key: &str, default: &str) -> String {
    std::env::var(key).unwrap_or_else(|_| default.to_string())
}

fn env_duration(key: &str, default_secs: u64) -> Duration {
    std::env::var(key)
        .ok()
        .and_then(|v| humantime_secs(&v))
        .map(Duration::from_secs)
        .unwrap_or_else(|| Duration::from_secs(default_secs))
}

fn humantime_secs(s: &str) -> Option<u64> {
    let s = s.trim();
    if let Some(v) = s.strip_suffix('s') {
        return v.parse().ok();
    }
    if let Some(v) = s.strip_suffix('m') {
        return v.parse::<u64>().ok().map(|n| n * 60);
    }
    if let Some(v) = s.strip_suffix('h') {
        return v.parse::<u64>().ok().map(|n| n * 3600);
    }
    s.parse().ok()
}

impl Config {
    pub fn from_env() -> Result<Self> {
        let r2_endpoint = std::env::var("R2_ENDPOINT")
            .map_err(|_| AgentError::Config("missing required env var R2_ENDPOINT".into()))?;
        let r2_access_key_id = std::env::var("AWS_ACCESS_KEY_ID")
            .map_err(|_| AgentError::Config("missing required env var AWS_ACCESS_KEY_ID".into()))?;
        let r2_secret_access_key = std::env::var("AWS_SECRET_ACCESS_KEY").map_err(|_| {
            AgentError::Config("missing required env var AWS_SECRET_ACCESS_KEY".into())
        })?;

        let partial_paths = env_or(
            "PARTIAL_PATHS",
            "sites-enabled,snippets,certs,streams-enabled",
        )
        .split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();

        Ok(Config {
            r2_endpoint,
            r2_bucket: env_or("R2_BUCKET", "certificate-bucket-1"),
            r2_prefix: env_or("R2_PREFIX", "nginx"),
            r2_access_key_id,
            r2_secret_access_key,

            domains_file: PathBuf::from(env_or("DOMAINS_FILE", "/etc/acme-sh/domains.txt")),
            cert_issuer_script: PathBuf::from(env_or("CERT_ISSUER_SCRIPT", "/usr/local/bin/certs")),
            acme_challenge_target: env_or(
                "ACME_CHALLENGE_TARGET",
                "_acme-challenge.artisanhosting.net",
            ),

            source_tree: PathBuf::from(env_or("SOURCE_TREE", "/mnt/nginx_local")),
            etc_nginx: PathBuf::from(env_or("ETC_NGINX", "/etc/nginx")),
            sync_root: PathBuf::from(env_or("SYNC_ROOT", "/var/lib/nginx-sync")),
            work_root: PathBuf::from(env_or("WORK_ROOT", "/opt/nginx-publisher")),
            state_dir: PathBuf::from(env_or("STATE_DIR", "/var/lib/ais-domain-agent")),

            sync_mode: env_or("MODE", "full"),
            partial_paths,
            keep_backups: env_or("KEEP_BACKUPS", "10").parse().unwrap_or(10),
            keep_stage: env_or("KEEP_STAGE", "false").parse().unwrap_or(false),

            listen_addr: env_or("LISTEN_ADDR", "127.0.0.1:8089"),

            dns_recheck_interval: env_duration("DNS_RECHECK_INTERVAL", 60),
            sync_interval: env_duration("SYNC_INTERVAL", 30),
            publish_interval: env_duration("PUBLISH_INTERVAL", 43200),
        })
    }
}

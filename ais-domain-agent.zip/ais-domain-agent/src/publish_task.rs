use std::path::Path;

use serde::Serialize;
use sha2::{Digest, Sha256};
use tokio::process::Command;
use tracing::info;
use walkdir::WalkDir;

use crate::config::Config;
use crate::errors::{AgentError, Result};
use crate::fsmirror::{copy_dir_async, mirror_dir_async};
use crate::r2::R2Client;

#[derive(Serialize)]
struct ManifestFile {
    path: String,
    sha256: String,
    bytes: u64,
}

#[derive(Serialize)]
struct Manifest {
    release_id: String,
    created_unix: i64,
    platform: String,
    file_count: usize,
    files: Vec<ManifestFile>,
}

pub async fn run_once(cfg: &Config, r2: &R2Client) -> Result<String> {
    let release_id = chrono::Utc::now().format("%Y-%m-%dT%H-%M-%SZ").to_string();
    let stage_dir = cfg.work_root.join("stage").join(&release_id);
    let stage_tree = stage_dir.join("tree");
    let manifest_path = stage_dir.join("manifest.json");

    tokio::fs::create_dir_all(&stage_tree).await?;

    info!(release = %release_id, "snapshotting source tree");
    copy_dir_async(cfg.source_tree.clone(), stage_tree.clone()).await?;

    test_nginx_tree(&stage_tree).await?;

    info!(release = %release_id, "writing manifest");
    write_manifest(&stage_tree, &release_id, &manifest_path).await?;

    let release_prefix = format!("{}/releases/{}", cfg.r2_prefix, release_id);
    info!(release = %release_id, "uploading tree to R2");
    r2.upload_tree(&stage_tree, &format!("{}/tree", release_prefix))
        .await?;

    info!(release = %release_id, "uploading manifest");
    r2.put_file(&format!("{}/manifest.json", release_prefix), &manifest_path)
        .await?;

    info!(release = %release_id, "updating latest pointer");
    r2.put_object_string(&format!("{}/latest", cfg.r2_prefix), &release_id)
        .await?;

    if !cfg.keep_stage {
        let _ = tokio::fs::remove_dir_all(&stage_dir).await;
    }

    Ok(release_id)
}

async fn test_nginx_tree(stage_tree: &Path) -> Result<()> {
    let status = Command::new("/sbin/nginx")
        .args(["-t", "-p"])
        .arg(stage_tree)
        .args(["-c", "nginx.conf"])
        .status()
        .await;

    if let Ok(s) = status {
        if s.success() {
            return Ok(());
        }
    }

    let sandbox_etc = stage_tree
        .parent()
        .unwrap()
        .join("sandbox")
        .join("etc")
        .join("nginx");
    mirror_dir_async(stage_tree.to_path_buf(), sandbox_etc.clone()).await?;

    let status = Command::new("/sbin/nginx")
        .arg("-t")
        .arg("-c")
        .arg(sandbox_etc.join("nginx.conf"))
        .status()
        .await?;

    if status.success() {
        Ok(())
    } else {
        Err(AgentError::Config(format!(
            "nginx config test failed in sandbox: {status}"
        )))
    }
}

async fn write_manifest(stage_tree: &Path, release_id: &str, manifest_path: &Path) -> Result<()> {
    let mut files = Vec::new();
    for entry in WalkDir::new(stage_tree).follow_links(false) {
        let entry = entry.map_err(std::io::Error::from)?;
        if entry.file_type().is_dir() {
            continue;
        }
        let rel = entry
            .path()
            .strip_prefix(stage_tree)
            .unwrap()
            .to_string_lossy()
            .replace('\\', "/");
        let bytes = tokio::fs::read(entry.path()).await?;
        let sha256 = hex::encode(Sha256::digest(&bytes));
        files.push(ManifestFile {
            path: rel,
            sha256,
            bytes: bytes.len() as u64,
        });
    }
    files.sort_by(|a, b| a.path.cmp(&b.path));

    let manifest = Manifest {
        release_id: release_id.to_string(),
        created_unix: chrono::Utc::now().timestamp(),
        platform: format!("{}/{}", std::env::consts::OS, std::env::consts::ARCH),
        file_count: files.len(),
        files,
    };

    let json = serde_json::to_vec_pretty(&manifest)?;
    if let Some(parent) = manifest_path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    tokio::fs::write(manifest_path, json).await?;
    Ok(())
}

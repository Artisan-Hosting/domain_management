use tokio::process::Command;

use crate::errors::{AgentError, Result};

pub async fn resolve_cname(name: &str) -> Result<Option<String>> {
    let output = Command::new("dig")
        .args(["+short", "CNAME", name])
        .output()
        .await
        .map_err(|e| AgentError::Dns(format!("running dig for {name}: {e}")))?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(AgentError::Dns(format!(
            "dig exited non-zero for {name}: {stderr}"
        )));
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    let first_line = stdout.lines().next().map(|l| l.trim().to_string());

    Ok(first_line
        .filter(|l| !l.is_empty())
        .map(|l| l.trim_end_matches('.').to_string()))
}

pub async fn verify_acme_challenge(domain: &str, expected_target: &str) -> Result<bool> {
    let challenge_name = format!("_acme-challenge.{domain}");
    let resolved = resolve_cname(&challenge_name).await?;
    let expected = expected_target.trim_end_matches('.').to_lowercase();

    Ok(resolved
        .map(|r| r.to_lowercase() == expected)
        .unwrap_or(false))
}

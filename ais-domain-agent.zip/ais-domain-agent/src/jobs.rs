use std::collections::HashMap;
use std::sync::Arc;

use chrono::{DateTime, Utc};
use serde::Serialize;
use tokio::sync::RwLock;
use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum JobStatus {
    Running,
    Succeeded,
    Failed,
}

#[derive(Debug, Clone, Serialize)]
pub struct Job {
    pub id: Uuid,
    pub kind: String,
    pub status: JobStatus,
    pub started_at: DateTime<Utc>,
    pub finished_at: Option<DateTime<Utc>>,
    pub log: String,
    pub error: Option<String>,
}

#[derive(Clone, Default)]
pub struct JobStore {
    inner: Arc<RwLock<HashMap<Uuid, Job>>>,
}

impl JobStore {
    pub async fn start(&self, kind: &str) -> Uuid {
        let id = Uuid::new_v4();
        let job = Job {
            id,
            kind: kind.to_string(),
            status: JobStatus::Running,
            started_at: Utc::now(),
            finished_at: None,
            log: String::new(),
            error: None,
        };
        self.inner.write().await.insert(id, job);
        id
    }

    pub async fn succeed(&self, id: Uuid, log: String) {
        if let Some(job) = self.inner.write().await.get_mut(&id) {
            job.status = JobStatus::Succeeded;
            job.finished_at = Some(Utc::now());
            job.log = log;
        }
    }

    pub async fn fail(&self, id: Uuid, error: String) {
        if let Some(job) = self.inner.write().await.get_mut(&id) {
            job.status = JobStatus::Failed;
            job.finished_at = Some(Utc::now());
            job.error = Some(error);
        }
    }

    pub async fn get(&self, id: Uuid) -> Option<Job> {
        self.inner.read().await.get(&id).cloned()
    }
}

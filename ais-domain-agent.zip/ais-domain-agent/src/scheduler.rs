use chrono::Utc;
use tracing::{error, info, warn};

use crate::acme;
use crate::config::Config;
use crate::dns;
use crate::domain_store::{DomainState, DomainStore};
use crate::jobs::JobStore;
use crate::publish_task;
use crate::r2::R2Client;
use crate::sync_task;

pub async fn run_server_loops(
    cfg: Config,
    store: DomainStore,
    jobs: JobStore,
    r2: R2Client,
) {
    let dns_cfg = cfg.clone();
    let dns_store = store.clone();
    let dns_r2 = r2.clone();
    tokio::spawn(async move {
        let mut ticker = tokio::time::interval(dns_cfg.dns_recheck_interval);
        loop {
            ticker.tick().await;
            if let Err(e) = dns_recheck_pass(&dns_cfg, &dns_store, &dns_r2).await {
                error!(error = %e, "dns recheck pass failed");
            }
        }
    });

    let publish_cfg = cfg.clone();
    let publish_r2 = r2.clone();
    tokio::spawn(async move {
        let mut ticker = tokio::time::interval(publish_cfg.publish_interval);
        loop {
            ticker.tick().await;
            match publish_task::run_once(&publish_cfg, &publish_r2).await {
                Ok(release) => info!(release = %release, "periodic reconciliation publish complete"),
                Err(e) => error!(error = %e, "periodic reconciliation publish failed"),
            }
        }
    });
}

pub async fn run_sync_loop(cfg: Config, r2: R2Client) {
    let mut ticker = tokio::time::interval(cfg.sync_interval);
    loop {
        ticker.tick().await;
        if let Err(e) = sync_task::run_once(&cfg, &r2).await {
            error!(error = %e, "sync pass failed");
        }
    }
}

async fn dns_recheck_pass(cfg: &Config, store: &DomainStore, r2: &R2Client) -> crate::errors::Result<()> {
    let pending = store
        .domains_in_state(|s| matches!(s, DomainState::AwaitingCname))
        .await;

    for domain in pending {
        let Some(mut record) = store.get(&domain).await else {
            continue;
        };
        record.cname_checked_at = Some(Utc::now());

        match dns::verify_acme_challenge(&domain, &cfg.acme_challenge_target).await {
            Ok(true) => {
                info!(domain = %domain, "CNAME verified");
                record.state = DomainState::CnameVerified;
                record.cname_verified_at = Some(Utc::now());
                store.upsert(record).await?;
                issue_and_publish(cfg, store, r2, &domain).await;
            }
            Ok(false) => {
                store.upsert(record).await?;
            }
            Err(e) => {
                warn!(domain = %domain, error = %e, "CNAME check failed, will retry next tick");
                store.upsert(record).await?;
            }
        }
    }
    Ok(())
}

pub async fn issue_and_publish(cfg: &Config, store: &DomainStore, r2: &R2Client, domain: &str) {
    let verified_domains = store
        .domains_in_state(|s| {
            matches!(
                s,
                DomainState::CnameVerified | DomainState::CertIssued | DomainState::Published
            )
        })
        .await;

    if let Err(e) = acme::write_domains_file(&cfg.domains_file, &verified_domains).await {
        error!(domain = %domain, error = %e, "failed writing domains file");
        mark_failed(store, domain, e.to_string()).await;
        return;
    }

    match acme::run_cert_issuer(&cfg.cert_issuer_script).await {
        Ok(_log) => {
            if let Some(mut record) = store.get(domain).await {
                record.state = DomainState::CertIssued;
                record.cert_issued_at = Some(Utc::now());
                let _ = store.upsert(record).await;
            }
        }
        Err(e) => {
            error!(domain = %domain, error = %e, "cert issuance failed");
            mark_failed(store, domain, e.to_string()).await;
            return;
        }
    }

    match publish_task::run_once(cfg, r2).await {
        Ok(release) => {
            if let Some(mut record) = store.get(domain).await {
                record.state = DomainState::Published;
                record.published_at = Some(Utc::now());
                let _ = store.upsert(record).await;
            }
            info!(domain = %domain, release = %release, "published after issuance");
        }
        Err(e) => {
            error!(domain = %domain, error = %e, "publish after issuance failed");
            mark_failed(store, domain, e.to_string()).await;
        }
    }
}

async fn mark_failed(store: &DomainStore, domain: &str, reason: String) {
    if let Some(mut record) = store.get(domain).await {
        record.last_error = Some(reason.clone());
        record.state = DomainState::Failed { reason };
        let _ = store.upsert(record).await;
    }
}
